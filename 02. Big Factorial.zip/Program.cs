﻿using System;
using System.Numerics;

namespace _02._Big_Factorial
{
    class Program
    {
        static void Main(string[] args)
        {
            int numRange = int.Parse(Console.ReadLine());

            BigInteger factorial = 1;

            for (int i = 2; i <= numRange; i++)
            {
                factorial *= i;
            }
            Console.WriteLine(factorial);

        }
    }
}
