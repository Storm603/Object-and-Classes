﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _05._Students_2._0
{
    class Students
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Age { get; set; }
        public string Hometown { get; set; }

    }

    class Program
    {
        static void Main(string[] args)
        {


            string[] studentInfo = Console.ReadLine().Split().ToArray();

            List<Students> collection = new List<Students>();

            while (studentInfo[0] != "end")
            {
                string firstName = studentInfo[0];
                string lastName = studentInfo[1];
                string age = studentInfo[2];
                string hometown= studentInfo[3];



                if (IsStudentExisting(collection, firstName, lastName))
                {
                    Students students = GetStudents(collection, firstName, lastName);

                    students.FirstName = firstName; 
                    students.LastName = lastName;
                    students.Age = age;
                    students.Hometown = hometown;
                }
                else
                {
                    Students student = new Students();

                    student.FirstName = firstName;
                    student.LastName = lastName;
                    student.Age = age;
                    student.Hometown = hometown;

                    collection.Add(student);
                }


                studentInfo = Console.ReadLine().Split().ToArray();
            }

            string searchByCity = Console.ReadLine();

            foreach (Students student in collection)
            {
                if (student.Hometown == searchByCity)
                {
                    Console.WriteLine($"{student.FirstName} {student.LastName} is {student.Age} years old.");
                }
            }

        }

        static bool IsStudentExisting(List<Students> collection, string firstName, string lastName)
        {
            foreach (Students student in collection)
            {
                if (student.FirstName == firstName && student.LastName == lastName)
                {
                    return true;
                }
            }
            return false;
        }

        static Students GetStudents(List<Students> collection, string firstName, string lastName)
        {
            Students existingStudent = null;

            foreach (Students student in collection)
            {
                if (student.FirstName == firstName && student.LastName == lastName)
                {
                    existingStudent = student;
                }
            }

            return existingStudent;
        }
    }
}
