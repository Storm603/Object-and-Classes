﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _03._Songs
{
    class Songs
    {
        public string TypeList { get; set; }
        public string Name { get; set; }
        public string Time { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<Songs> collection = new List<Songs>();

            int numberOfSongs = int.Parse(Console.ReadLine());

            for (int i = 1; i <= numberOfSongs; i++)
            {
                string[] format = Console.ReadLine().Split("_").ToArray();

                string typeLists = format[0];
                string name = format[1];
                string time = format[2];

                Songs song = new Songs();

                song.TypeList = typeLists;
                song.Name = name;
                song.Time = time;

                collection.Add(song);
            }

            string typeList = Console.ReadLine();

            if (typeList == "all")
            {
                foreach (Songs song in collection)
                {
                    Console.WriteLine(song.Name);
                }
            }
            else
            {
                foreach (Songs song in collection)
                {
                    if (song.TypeList == typeList)
                    {
                        Console.WriteLine(song.Name);
                    }
                }
            }
        }
    }
}
