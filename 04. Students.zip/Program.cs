﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _04._Students
{
    class Students
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Age { get; set; }
        public string Hometown { get; set; }

        

    }

    class Program
    {
        static void Main(string[] args)
        {

            string[] studentInfo = Console.ReadLine().Split().ToArray();

            List<Students> collection = new List<Students>();

            while (studentInfo[0] != "end")
            {
                Students student = new Students();

                student.FirstName = studentInfo[0];
                student.LastName = studentInfo[1];
                student.Age = studentInfo[2];
                student.Hometown = studentInfo[3];

                collection.Add(student);

                studentInfo = Console.ReadLine().Split().ToArray();
            }

            string searchByCity = Console.ReadLine();

            foreach (Students student in collection)
            {
                if (student.Hometown == searchByCity)
                {
                    Console.WriteLine($"{student.FirstName} {student.LastName} is {student.Age} years old.");
                }
            }

        }
    }
}
