﻿using System;
using System.Linq;

namespace _01._Randomize_Words
{
    class Program
    {
        static void Main(string[] args)
        {

            string[] array = Console.ReadLine().Split().ToArray();


            Random rnd = new Random();

            for (int i = 0; i <= array.Length - 1; i++)
            {
                int word = rnd.Next(array.Length);

                string saved = array[word];

                array[word] = array[i];

                array[i] = saved;


            }
            Console.WriteLine(string.Join(Environment.NewLine, array));
        }
    }
}
