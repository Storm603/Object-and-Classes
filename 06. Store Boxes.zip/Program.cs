﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _06._Store_Boxes
{
    class Item
    {
        public string Name { get; set; }
        public decimal Price { get; set; }
    }

    class Box
    {
        public int SerialNumber { get; set; }
        public string Item { get; set; }
        public int ItemQuantity{ get; set; }
        public decimal PriceForABox{ get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            string[] dataInput = Console.ReadLine().Split().ToArray();

            List<string> dataInfoCollection = new List<string>();

            while (dataInput[0] != "end")
            {
                int serialNumber = int.Parse(dataInput[0]);
                string itemName = dataInput[1];
                int itemQuantity = int.Parse(dataInput[2]);
                decimal itemPrice = decimal.Parse(dataInput[3]);

                decimal priceOfOneBox = itemQuantity * itemPrice;

                Item info = new Item();

                info.Name = itemName;



            }
        }
    }
}
